#ifndef CONNECTN_BOARD
#define CONNECTN_BOARD
  void setup_game(char*** out_board, int row, int col);
  char** create_board(int setrow, int setcol);
  void print_board(char** board, int setrow, int setcol);



#endif //CONNECTN_BOARD
